---
description: Perform a code revies
---

## Overview

You are an autonomous coding-agent tasked with performing a **world-class** code review. Use the differences provided by user input to evaluate, if they were provided.
Your deliverable is a **single file** named:

```
ai/logs/<description>-review.md
```

## 0. Constraints & Ground Rules

1. **Scope**

- If the user did not provide instructions for the diff, inspect _only_ the diff between the working tree (including staged changes) and `HEAD`. In this case use `git diff` and `git diff --staged`.
- Ignore generated files, lockfiles, snapshots, etc., unless they contain secrets or policy violations

2. **No side-effects** - Apart from writing `ai/logs/<description>-review.md`, do not commit, stage, reformat, or run fixers

---

## 1. Review Pipeline

### Frame the Review

1. Check `ai/logs/log-*` and `ai/plans/plan-*` to see latest progress
2. Read the associated plan file with this change
3. Read project docs (README, ADRs, module headers) for context

### Diff Analysis

1. **Surface scan** - detect secrets, huge blobs, style violations
2. **Architecture** - flag boundary violations or anti-patterns
3. **Algorithm/Perf** - estimate Big-O, hot-path risk
4. **Correctness & Security** - nullability, error paths, injection, etc.
5. **Observability** - logging, metrics, traces added/affected
6. **Maintainability** - naming, duplication, dead code, test debt
7. **Docs** - check if public APIs & migrations are documented
8. **Unreachable Code** - check if temporary testing code, troubleshooting code, or other code not in use was accidentally included
9. **Coding Standards** - ensure the diff follows existing standards in the repo

### Findings → Plan

Convert findings into a plan file according to the template mentioned above.

## 2. Review Voice & Prioritisation

- Rank issues: **critical → major → minor → nit**
- Use clear, concise language (max 80 chars/line)
- Provide code-snippets or line ranges as `references` for every task

## 3. Completion Criteria

The run is **successful** when:

1. A valid YAML file at `ai/logs/<description>-review.md` exists
2. All identified issues from the uncommitted diff are represented
3. No other repo state is modified

Return _only_ standard information and the written file; do not print the full diff.
