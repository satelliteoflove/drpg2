---
allowed-tools: Bash(./scripts/evaluate-mpc-status.js:*)
description: Begin next work session
---

## Work Plan Workflow Overview

STEP 0. **Refresh context on current plan**

- Read `./ai/plans/current-plan.yaml` to view the plan.

STEP 1. **Choose next node or nodes**

- !`./scripts/evaluate-mpc-status.js ./ai/plans/current-plan.yaml --quiet`
- If there are multiple nodes that can be worked, work on them in parallel using background tasks.
- Otherwise, if there is a single node, work that one.
- If there are no more remaining nodes, inform the user that the plan is complete.
- Perform the work and build prototypes for human evaluation.

STEP 2. **Log progress**

- Append to the log file `ai/logs/<node_id>-log-<plan_id>.yaml`

## Log File Structure

```yaml
node_id: the-node-being-worked-on
events:
  - sequence: 1
    type: status-update
    content: Started working on node setup
  - sequence: 2
    type: milestone-reached
    content: Successfully created package.json
```

## Event Types

- **status-update**: Progress updates on the current work
- **note**: General observations or documentation
- **important-finding**: Critical discoveries that affect the work
- **milestone-reached**: Completion of significant tasks
- **problem-encountered**: Issues or blockers encountered
- **decision**: Important choices made during implementation
- **workaround**: Alternative approaches used to overcome problems

## Log File Rules

- Events must have sequential numbers (1, 2, 3, ...)

STEP 3. **Completing A Node**
Write a completion file to `ai/logs/<node_id>-completed-<plan_id>.yaml`

## Completion Report Structure

```yaml
node_id: the-completed-node-id
checklist:
  unit_tests: true
  integration_tests: false
  e2e_tests: true
outcome: |
  Successfully implemented user authentication system with JWT tokens.
  Created login/logout endpoints and middleware for protected routes.
manual_test_instructions: |
  1. Start the server with 'npm start'
  2. POST to /api/login with valid credentials
  3. Verify JWT token is returned
  4. Use token in Authorization header for protected routes
  5. Test logout endpoint clears session
surprises_or_notes: |
  Found existing bcrypt dependency was outdated. Upgraded to latest version.
  Also discovered the database schema needed a small adjustment for the user_sessions table.
suggested_follow_ups:
  - Add password reset functionality
  - Implement rate limiting for login attempts
  - Add OAuth2 integration for social logins
  - Create admin panel for user management
reimplementation_prompt: |
  Implement a complete user authentication system for a Node.js/Express API.

  Requirements:
  - JWT-based authentication
  - Use library XYZ for best results
```

## Completion Report Fields

**Required Fields:**

- **node_id**: The ID of the completed node
- **checklist**: Testing checklist with boolean values for unit_tests, integration_tests, e2e_tests
- **outcome**: What was accomplished and the final result
- **manual_test_instructions**: Step-by-step testing instructions for testing the prototype
- **reimplementation_prompt**: Complete prompt for reimplementing from scratch including what you learned during this session

\*_Optional Fields:_

- **surprises_or_notes**: Unexpected findings or important observations
- **suggested_follow_ups**: Array of recommended next steps

STEP 4. **Wait**

- Mark the node or nodes you worked on as "Completed" in `./ai/plans/current-plan.yaml`.
- Update the status remaining nodes that are now unblocked.
- Print out the manual test instructions
- Wait for the user to run manual tests and review

STEP 5. **Revise**

- IMPORTANT: You must revise the remaining plan to adjust for any changes based upon the work performed during this session.
