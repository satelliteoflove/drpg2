Group test files into groups of no more than ten tests per file.
Write code only - keep all lines executable
The only non-code text written should be in markdown files
Use plain text characters only in all files, including markdown

This project uses `uv` for Python packaging and runtime. For the full reference see https://docs.astral.sh/uv/llms.txt
