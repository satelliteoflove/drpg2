---
description: Fix failing tests
---

# Instructions

- Fix anything that is broken when running the provided test command.
- Review testing standards in @.claude/commands/refactor/clean-tests.md
