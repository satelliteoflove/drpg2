---
description: Answer questions
---

- Do not change any files or implement solutions.
- Use whatever tools are required in order to answer my questions.
