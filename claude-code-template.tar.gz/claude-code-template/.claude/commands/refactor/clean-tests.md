---
description: Audit, rewrite, and reduce tests in a codebase
---

# Grouping

- Do not make test files too large. Try to group test files into groups of less than ten tests.

# Rules

- Remove duplicate tests.
- Remove or improve tests that violate our standards

# Standards

- Test the "What," Not the "How"
- Treat the code under test as a black box
- Test Public Interfaces Only
- Test One Thing at a Time
- Avoid Testing Implementation Details

# Instructions

- After the above, fix anything that is broken when running `pnpm run test:all`.
