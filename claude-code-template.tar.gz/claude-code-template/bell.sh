#!/bin/bash

osascript -e "display notification \"Claude Code: \" with title \"Work Completed In $(basename $PWD)\""
