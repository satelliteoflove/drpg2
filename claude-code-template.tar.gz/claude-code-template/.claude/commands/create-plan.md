---
description: Create new plan file
---

Create a plan file based on the provided context. Ultrathink about it.

## Quick Start

To create a valid plan file, you need:

1. Required top-level fields: version, plan_id, project_name, agent_profile, architecture, tooling, entry_node, nodes
2. Exactly one root node (a node with no incoming edges)
3. The entry_node must be the root node
4. All nodes must have: id, status, materialization, description, detailed_description, outputs, agent_action, role
5. An example plan file lives in `./ai/plans/example-plan-file.yaml`

## Schema Structure

### Top-Level Fields

```yaml
version: "0.5"
plan_id: "unique-identifier"
project_name: "Human-readable name"
agent_profile: "ai-coding-agent-v1"
entry_node: "root-node-id" # Must be the root node

context: # Optional
  business_goal: "High-level objective"
  non_functional_requirements: ["Performance", "Security"]
  personas:
    - name: "Developer"
      need: "Clean API"

architecture:
  overview: "System architecture description" # Required
  constraints: ["No external deps"] # Optional
  integration_points: ["External APIs"] # Optional

tooling:
  primary_language: "TypeScript" # Required
  frameworks: ["React", "Node.js"] # Required, min 1
  package_manager: "npm" # Required
  secondary_languages: ["SQL"] # Optional
  coding_standards: # Optional
    lint: "eslint"
    formatting: "prettier"
    testing: "jest"

nodes: [] # Array of node objects
```

### Node Structure

```yaml
- id: "unique-node-id"
  status: "Ready" # Enum: Completed, Ready, In Progress, Blocked, Paused, Waiting
  materialization: 0.8 # 0.0-1.0, how committed this node is
  description: "Brief one-line description"
  detailed_description: |
    Multi-line detailed guidance for execution.
    Be specific about files, commands, and expected outcomes.
  outputs: ["src/file.ts", "api/*.js"] # Required array
  agent_action: "Specific action for agent" # Required
  role: "agent" # Required: "agent" or "human"

  # Optional fields
  inputs: ["dependency-files"]
  acceptance_criteria: ["Tests pass", "No lint errors"]
  definition_of_done: "Clear completion criteria"
  required_knowledge: ["React hooks", "AWS CDK"]
  downstream: ["next-node-id", "another-node-id"]
```

## Key Rules

1. **Graph Structure**: Must have exactly one root node (no incoming edges)
2. **Entry Node**: Must be the root node
3. **Materialization**: Entry node should have 1.0, downstream nodes lower
4. **Status Values**: Use correct enum values
5. **Downstream References**: All referenced node IDs must exist
6. **Role Assignment**: Each node must have role "agent" or "human"
7. **Agent Workflow**: Agents should not work on "human" role nodes or nodes dependent on incomplete "human" nodes

## Minimal Valid Example

```yaml
version: "0.5"
plan_id: "minimal-001"
project_name: "Minimal Example"
agent_profile: "ai-coding-agent-v1"
architecture:
  overview: "Simple application"
tooling:
  primary_language: "JavaScript"
  frameworks: ["Node.js"]
  package_manager: "npm"
entry_node: "setup"
nodes:
  - id: "setup"
    status: "Ready"
    materialization: 1.0
    description: "Initialize project"
    detailed_description: "Create package.json and basic structure"
    outputs: ["package.json"]
    agent_action: "Generate project files"
    role: "agent"
    downstream: ["implement"]
  - id: "implement"
    status: "Blocked"
    materialization: 0.7
    description: "Implement core feature"
    detailed_description: "Build the main functionality"
    outputs: ["src/index.js"]
    agent_action: "Write implementation"
    role: "agent"
```

## Gathering Context

- The user has provided you with context in this prompt.
- You can explore the codebase of this project for additional context.
- Use a file called `./ai/logs/<PLAN DESCRIPTION>.md` to record your analysis about the plan.
- You can ask clarifying questions for additional context.

## Writing The File

When you have all the required context to write the plan file:

Write `./ai/plans/plan-00N-slug.yaml`, where:

- `00N` is the next available number
- `slug` is a short, lowercase, dash-separated description
- Examples:
  - `plan-001-add-oauth.yaml`
  - `plan-002-introduce-background-threads.yaml`
- Symlink the file you created to `./ai/plans/current-plan.yaml`. Overwrite the symlink if necessary.
- Reference the file `./ai/logs/<PLAN DESCRIPTION>.md` in the plan.

After writing the file, verify it with the command: `./scripts/verify-mpc-structure.js ./ai/plans/current-plan.yaml`
