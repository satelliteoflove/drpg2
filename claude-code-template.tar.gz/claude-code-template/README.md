# claude-code-template

## Overview

This repo is designed as a template with examples you can use to configure Claude Code.

## Instructions

- Copy the `.claude/commands` into either your global directory `~/.claude/commands` or into your project directory `/your/project/.claude/commands`
- Edit the commands to your liking.
- Copy the `settings.json` either into the global directory or project directory and edit to your preference.

## Bell

The `bell.sh` configuration is helpful to receive macOS notifications when Claude Code finishes work.
Copy it to a location and configure the hook in `settings.json` to point to it.

## git-wip

- Install https://github.com/bartman/git-wip
  This ensures that Claude Code will save your work to a wip ref after every turn. The wip ref is a backup in case you ever need it.

## Claude Code Tips

- Make sure rip-grep is installed. Claude Code will intelligently use it.
- For thinking heavy tasks, tell Claude Code to "Ultrathink" about it.
- When you run commands like `/some-cc-command and here is what I want you to know` you can provide context after the command as shown.
- Unlike Cursor, Claude Code will not automatically include relevant commands, so for things you want loaded every time put them into your `CLAUDE.md` file.
- Project local settings, `CLAUDE.md` files, and commands take precedence over system wide settings.
- If you accidentally Ctrl-C or end a claude code session, and want to resume it, run `claude -c` to resume it.
- Check out the official docs: https://docs.anthropic.com/en/docs/claude-code/overview

## Just Files

- The [justfile](https://github.com/casey/just) is optional. I use it as a wrapper over common tasks and usually add it to `.gitignore`.
- Configure your justfile to run tests sequentially, fastest to slowest, and configure your tests to bail after <5 errors, and to only output failure info.

## Testing

- Ensure all tests pass after every significant piece of work.

# uv - Fast Python Package Manager

## Overview

uv is an extremely fast Python package and project manager written in Rust. It serves as a drop-in replacement for pip, pip-tools, pipx, poetry, pyenv, virtualenv, and more. Key benefits include:

## Common Commands

### Python Management

```bash
uv python list
uv python install 3.12
uv python pin 3.12
```

### Project Initialization

```bash
uv init
uv init --app
uv init --lib
uv init --script hello.py
```

### Virtual Environment Management

You do not need to worry about "activating" venvs with uv. Just prefix your commands like `uv run main.py`
But if you still want to activate one, run `uv venv`.

### Package Management

```bash
uv sync
uv add package-name
uv remove package-name
```

### Running Scripts

```bash
uv run python script.py
uv run pytest
uv run --with package-name python script.py
```

## Project-Specific Commands

### Formatting, Linting, Testing

```bash
uv run black .
uv run ruff check .
uv run pytest
```

But it is easier to use the "justfile" for these.

```bash
just format
just lint
just test
```

### Building

```bash
uv build
uv publish
```

### Common Workflows

```bash
# Install all dependencies
uv sync

# Add a new dependency
uv add requests

# Add a dev dependency
uv add --dev pytest

# Update dependencies
uv lock --upgrade

# Run with temporary dependencies
uv run --with pandas python analyze.py
```

## Tips

- Use `uv` instead of `pip` for faster installs
- Use `uv run` to execute commands in the virtual environment without activating it
- Use `uv tool` for installing CLI tools globally without affecting project dependencies
- Use `--python 3.12` to specify Python version for any command
