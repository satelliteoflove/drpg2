#!/usr/bin/env python3

import sys
import yaml
from pathlib import Path
from typing import Dict, List, Set
import argparse


def parse_args():
    parser = argparse.ArgumentParser(description="Verify MPC structure")
    parser.add_argument(
        "file_path",
        nargs="?",
        default="ai/plans/current-plan.yaml",
        help="Path to the YAML plan file",
    )
    return parser.parse_args()


def check_completion_status(node_id: str, plan_id: str, base_dir: Path) -> bool:
    completed_file_path = base_dir / "logs" / f"{node_id}-completed-{plan_id}.yaml"
    return completed_file_path.exists()


def calculate_level(
    node_id: str, child_to_parents: Dict[str, List[str]], visited: Set[str] = None
) -> int:
    if visited is None:
        visited = set()

    if node_id in visited:
        return -1
    visited.add(node_id)

    if node_id not in child_to_parents:
        return 0

    parents = child_to_parents[node_id]
    parent_levels = [
        calculate_level(parent_id, child_to_parents, visited.copy())
        for parent_id in parents
    ]
    return max(parent_levels) + 1


def main():
    args = parse_args()
    file_path = Path(args.file_path)

    if not file_path.exists():
        print(f"Error: File not found: {file_path}", file=sys.stderr)
        sys.exit(1)

    try:
        with open(file_path, "r") as f:
            data = yaml.safe_load(f)

        print(f"\nVerifying MPC structure for: {file_path}")
        print("=" * 51)

        if "nodes" not in data or not isinstance(data["nodes"], list):
            print("Error: No nodes array found in YAML file", file=sys.stderr)
            sys.exit(1)

        node_map = {node["id"]: node for node in data["nodes"]}
        child_to_parents: Dict[str, List[str]] = {}

        for node in data["nodes"]:
            if "downstream" in node and isinstance(node["downstream"], list):
                for child_id in node["downstream"]:
                    if child_id not in child_to_parents:
                        child_to_parents[child_id] = []
                    child_to_parents[child_id].append(node["id"])

        root_nodes = [
            node for node in data["nodes"] if node["id"] not in child_to_parents
        ]

        print(f"\nTotal nodes: {len(data['nodes'])}")
        print(f"Root nodes found: {len(root_nodes)}")

        if len(root_nodes) == 0:
            print("\n❌ ERROR: No root nodes found! The graph might have cycles.")
        elif len(root_nodes) == 1:
            print("\n✅ SUCCESS: Exactly one root node found!")
            print(f'   Root node ID: "{root_nodes[0]["id"]}"')
            print(f'   Description: "{root_nodes[0]["description"]}"')

            if "entry_node" in data:
                if data["entry_node"] == root_nodes[0]["id"]:
                    print(
                        f'   ✅ entry_node correctly points to root: "{data["entry_node"]}"'
                    )
                else:
                    print(
                        f'   ⚠️  WARNING: entry_node "{data["entry_node"]}" doesn\'t match root node "{root_nodes[0]["id"]}"'
                    )
        else:
            print("\n❌ ERROR: Multiple root nodes found!")
            print("   The following nodes have no parents:")
            for node in root_nodes:
                print(f'   - "{node["id"]}": {node["description"]}')

        print("\n--- Additional Checks ---")

        visited = set()
        queue = [n["id"] for n in root_nodes]

        while queue:
            node_id = queue.pop(0)
            if node_id in visited:
                continue
            visited.add(node_id)

            node = node_map.get(node_id)
            if node and "downstream" in node:
                for child_id in node["downstream"]:
                    if child_id not in visited:
                        queue.append(child_id)

        orphaned_nodes = [node for node in data["nodes"] if node["id"] not in visited]
        if orphaned_nodes:
            print(
                f"\n⚠️  WARNING: {len(orphaned_nodes)} orphaned nodes found (not reachable from root):"
            )
            for node in orphaned_nodes:
                print(f'   - "{node["id"]}": {node["description"]}')
        else:
            print("✅ All nodes are reachable from root")

        multi_parent_nodes = []
        for child_id, parents in child_to_parents.items():
            if len(parents) > 1:
                multi_parent_nodes.append({"id": child_id, "parents": parents})

        if multi_parent_nodes:
            print(f"\n⚠️  Note: {len(multi_parent_nodes)} nodes have multiple parents:")
            for item in multi_parent_nodes:
                parent_list = ", ".join([f'"{p}"' for p in item["parents"]])
                print(f'   - "{item["id"]}" is referenced by: {parent_list}')

        missing_refs = []
        for node in data["nodes"]:
            if "downstream" in node:
                for child_id in node["downstream"]:
                    if child_id not in node_map:
                        missing_refs.append({"parent": node["id"], "missing": child_id})

        if missing_refs:
            print(f"\n❌ ERROR: {len(missing_refs)} missing node references found:")
            for ref in missing_refs:
                print(
                    f'   - Node "{ref["parent"]}" references non-existent node "{ref["missing"]}"'
                )

        base_dir = file_path.parent.parent
        plan_id = data.get("plan_id", "")
        completed_nodes = {
            node["id"]
            for node in data["nodes"]
            if check_completion_status(node["id"], plan_id, base_dir)
        }

        node_levels = {
            node["id"]: calculate_level(node["id"], child_to_parents)
            for node in data["nodes"]
        }

        level_groups: Dict[int, List[str]] = {}
        for node_id, level in node_levels.items():
            if level not in level_groups:
                level_groups[level] = []
            level_groups[level].append(node_id)

        print("\n--- Parallel Readiness Check ---")
        parallel_readiness_issues = []

        sorted_levels = sorted(level_groups.keys())

        for level in sorted_levels:
            nodes = level_groups[level]
            available_nodes = []
            should_be_ready_nodes = []

            for node_id in nodes:
                node = node_map[node_id]
                parents = child_to_parents.get(node_id, [])
                all_parents_complete = all(
                    parent_id in completed_nodes for parent_id in parents
                )

                if node_id not in completed_nodes:
                    if node_id not in child_to_parents or all_parents_complete:
                        available_nodes.append(node_id)
                        if node.get("status") not in ["Ready", "READY"]:
                            should_be_ready_nodes.append(
                                {
                                    "id": node_id,
                                    "currentStatus": node.get("status", "None"),
                                    "description": node["description"],
                                }
                            )

            if should_be_ready_nodes:
                parallel_readiness_issues.append(
                    {"level": level, "nodes": should_be_ready_nodes}
                )

        if parallel_readiness_issues:
            print("\n❌ ERROR: Found nodes that should be marked as READY:")
            for issue in parallel_readiness_issues:
                print(f"\n   Level {issue['level']}:")
                for node_info in issue["nodes"]:
                    print(
                        f"   - \"{node_info['id']}\" (currently: {node_info['currentStatus']})"
                    )
                    print(f"     {node_info['description']}")
        else:
            print("✅ All available nodes are correctly marked as READY")

        print("\n" + "=" * 50)

        if (
            len(root_nodes) == 1
            and len(orphaned_nodes) == 0
            and len(missing_refs) == 0
            and len(parallel_readiness_issues) == 0
        ):
            print("✅ MPC structure is valid!\n")
            sys.exit(0)
        else:
            print("❌ MPC structure has issues that need to be fixed.\n")
            sys.exit(1)

    except Exception as e:
        print(f"Error parsing YAML file: {e}", file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()
