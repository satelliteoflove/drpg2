def main():
    print("Hello from claude-code-template!")


if __name__ == "__main__":
    main()
