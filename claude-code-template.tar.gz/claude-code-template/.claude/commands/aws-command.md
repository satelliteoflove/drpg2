---
description: Write a Python AWS script
---

# How To Write AWS Scripts

- This project uses python3 and uv for package management and python runtime.
- Each script should be executable independently
- Use the latest version of the boto3 sdk
- Create a new Python file in ./src
- API output should always be logged to the ./ai/logs directory in json, named with the timestamp.
- The results of the script should be written in json and csv formats to the ./ai/logs directory, named with the script name and timestamp.
