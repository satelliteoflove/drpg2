#!/usr/bin/env python3

import sys
import yaml
from pathlib import Path
from typing import Dict, List, Set
import argparse


def parse_args():
    parser = argparse.ArgumentParser(description="Evaluate MPC Status")
    parser.add_argument(
        "file_path",
        nargs="?",
        default="ai/plans/current-plan.yaml",
        help="Path to the YAML plan file",
    )
    parser.add_argument(
        "--quiet", action="store_true", help="Quiet mode - minimal output"
    )
    return parser.parse_args()


def check_completion_status(node_id: str, plan_id: str, base_dir: Path) -> bool:
    completed_file_path = base_dir / "logs" / f"{node_id}-completed-{plan_id}.yaml"
    return completed_file_path.exists()


def calculate_level(
    node_id: str, child_to_parents: Dict[str, List[str]], visited: Set[str] = None
) -> int:
    if visited is None:
        visited = set()

    if node_id in visited:
        return -1
    visited.add(node_id)

    if node_id not in child_to_parents:
        return 0

    parents = child_to_parents[node_id]
    parent_levels = [
        calculate_level(parent_id, child_to_parents, visited.copy())
        for parent_id in parents
    ]
    return max(parent_levels) + 1


def get_node_status(
    node_id: str, completed_nodes: Set[str], child_to_parents: Dict[str, List[str]]
) -> str:
    if node_id in completed_nodes:
        return "✅ COMPLETED"

    if node_id not in child_to_parents:
        return "🚀 READY"

    parents = child_to_parents[node_id]
    all_parents_complete = all(parent_id in completed_nodes for parent_id in parents)

    if all_parents_complete:
        return "🟢 AVAILABLE"

    some_parents_complete = any(parent_id in completed_nodes for parent_id in parents)
    if some_parents_complete:
        return "🟡 PARTIAL"

    return "⏳ BLOCKED"


def main():
    args = parse_args()
    file_path = Path(args.file_path)
    quiet_mode = args.quiet

    if not file_path.exists():
        print(f"Error: File not found: {file_path}", file=sys.stderr)
        sys.exit(1)

    try:
        with open(file_path, "r") as f:
            data = yaml.safe_load(f)

        if not quiet_mode:
            print(f"\n🔍 Evaluating MPC Status: {file_path}")
            print("=" * 61)

        if "nodes" not in data or not isinstance(data["nodes"], list):
            print("Error: No nodes array found in YAML file", file=sys.stderr)
            sys.exit(1)

        node_map = {node["id"]: node for node in data["nodes"]}
        child_to_parents: Dict[str, List[str]] = {}
        completed_nodes: Set[str] = set()

        base_dir = file_path.parent.parent
        plan_id = data.get("plan_id", "")

        for node in data["nodes"]:
            if check_completion_status(node["id"], plan_id, base_dir):
                completed_nodes.add(node["id"])

            if "downstream" in node and isinstance(node["downstream"], list):
                for child_id in node["downstream"]:
                    if child_id not in child_to_parents:
                        child_to_parents[child_id] = []
                    child_to_parents[child_id].append(node["id"])

        if not quiet_mode:
            print("\n📊 Task Status Summary:")
            print(f"   Total nodes: {len(data['nodes'])}")
            print(f"   Completed: {len(completed_nodes)}")
            print(f"   Remaining: {len(data['nodes']) - len(completed_nodes)}")
            print(
                f"   Progress: {round((len(completed_nodes) / len(data['nodes'])) * 100)}%"
            )

        node_levels = {
            node["id"]: calculate_level(node["id"], child_to_parents)
            for node in data["nodes"]
        }

        level_groups: Dict[int, List[str]] = {}
        for node_id, level in node_levels.items():
            if level not in level_groups:
                level_groups[level] = []
            level_groups[level].append(node_id)

        if not quiet_mode:
            print("\n🔄 Task Execution Order (Parallelization Analysis):")
            print("-" * 61)

        sorted_levels = sorted(level_groups.keys())

        if not quiet_mode:
            for level in sorted_levels:
                nodes = level_groups[level]
                available_nodes = [
                    node_id
                    for node_id in nodes
                    if get_node_status(node_id, completed_nodes, child_to_parents)
                    in ["🚀 READY", "🟢 AVAILABLE"]
                ]

                print(
                    f"\n📍 Level {level} ({len(available_nodes)}/{len(nodes)} tasks can be worked):"
                )

                for node_id in nodes:
                    node = node_map[node_id]
                    status = get_node_status(node_id, completed_nodes, child_to_parents)
                    indent = "   "

                    print(f"{indent}{status} {node_id}")
                    print(f"{indent}      └─ {node['description']}")

                    if status in ["⏳ BLOCKED", "🟡 PARTIAL"]:
                        parents = child_to_parents.get(node_id, [])
                        blocking_parents = [
                            p for p in parents if p not in completed_nodes
                        ]
                        if blocking_parents:
                            print(
                                f"{indent}      └─ Blocked by: {', '.join(blocking_parents)}"
                            )

                if len(available_nodes) > 1:
                    print(
                        f"\n   💡 These {len(available_nodes)} tasks can be worked in parallel:"
                    )
                    for node_id in available_nodes:
                        print(f"      • {node_id}")

        statuses: Dict[str, List[str]] = {}
        for node in data["nodes"]:
            status = get_node_status(node["id"], completed_nodes, child_to_parents)
            if status not in statuses:
                statuses[status] = []
            statuses[status].append(node["id"])

        if not quiet_mode:
            print("\n\n📋 Detailed Status Breakdown:")
            print("-" * 61)

            status_order = [
                "✅ COMPLETED",
                "🟢 AVAILABLE",
                "🚀 READY",
                "🟡 PARTIAL",
                "⏳ BLOCKED",
            ]
            for status in status_order:
                if status in statuses:
                    nodes = statuses[status]
                    print(f"\n{status} ({len(nodes)} nodes):")
                    for node_id in nodes:
                        node = node_map[node_id]
                        print(f"   • {node_id}: {node['description']}")

        available_now = statuses.get("🚀 READY", []) + statuses.get("🟢 AVAILABLE", [])
        if available_now:
            print("\n\n🎯 Next Actions:")
            if not quiet_mode:
                print("-" * 61)
            print(f"You can work on {len(available_now)} task(s) right now:")
            for node_id in available_now:
                node = node_map[node_id]
                print(f"   ▶️  {node_id}: {node['description']}")
        elif len(completed_nodes) == len(data["nodes"]):
            print("\n\n🎉 All tasks completed!")
        else:
            print(
                "\n\n⚠️  No tasks are currently available. Check blocking dependencies."
            )

        if not quiet_mode:
            print("\n" + "=" * 60 + "\n")

    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()
