---
allowed-tools: Bash(git add:*), Bash(git status:*), Bash(git commit:*), Bash(git branch:*), Bash(git log:*), Bash(git diff:*)
description: Create a git commit
---

## Context

- Current git status: !`git status`
- Current branch: !`git branch --show-current`
- Recent commits: !`git log --oneline -10`
- Current git diff (staged and unstaged changes): !`git diff HEAD`

## Instructions

- Group uncommitted chunks into logical groups.
- If there is only one logical group, create a single commit.
- Otherwise, create a separate commit for each logical groups of chunks.
