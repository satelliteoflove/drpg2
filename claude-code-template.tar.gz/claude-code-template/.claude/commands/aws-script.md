---
description: Write an AWS Script
---

# How To Write AWS Scripts

- This project uses python3 and uv for python package management and runtime
- Each script should be executable independently
- Use the latest version of boto3
- Create a new Python file named based on my request in ./src.
- API output should always be written to stdout and logged to the ./ai/logs directory in json.
